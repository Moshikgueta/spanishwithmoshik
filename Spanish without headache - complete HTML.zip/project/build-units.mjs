import fs from 'node:fs';
import path from 'node:path';

const root = path.dirname(new URL(import.meta.url).pathname);
const manuscriptPath = path.join(root, 'manuscript-extracted.txt');
const manuscript = fs.readFileSync(manuscriptPath, 'utf8').replace(/\r/g, '');
const lines = manuscript.split('\n').map((line) => line.trim()).filter(Boolean);

const palette = {
  navy: '#1E3A5C',
  rust: '#B5502F',
  gold: '#E0A63C',
  cream: '#FBF7EF',
  paper: '#FFFFFF',
  ink: '#2A2520',
  muted: '#8A8172',
  green: '#3E6F5E',
};

function esc(value) {
  return value
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');
}

function stripTag(line, tag) {
  return line.replace(`[${tag}]`, '').trim();
}

function plain(value) {
  return value.replace(/[\u202a\u202b\u202c\u200e\u200f]/g, '');
}

function rich(value) {
  let out = '';
  let cursor = 0;
  const pattern = /\u202a([^\u202c]+)\u202c/g;
  for (const match of value.matchAll(pattern)) {
    out += esc(value.slice(cursor, match.index));
    out += `<span dir="ltr" class="es">${esc(match[1])}</span>`;
    cursor = match.index + match[0].length;
  }
  out += esc(value.slice(cursor));
  return out.replaceAll('\u00a0', ' ');
}

function titleParts(value) {
  const match = value.match(/^פרק\s+(\d+):\s*(.+)$/);
  return match ? { chapter: match[1], title: match[2] } : null;
}

function unitNumber(value) {
  const match = value.match(/(\d+)/);
  return match ? Number(match[1]) : 0;
}

function groupWhile(items, start, prefix) {
  const grouped = [];
  let index = start;
  while (index < items.length && items[index].startsWith(prefix)) {
    grouped.push(items[index]);
    index += 1;
  }
  return { grouped, next: index };
}

function renderChecklist(items, compact = false) {
  return `<div class="check-card${compact ? ' compact' : ''}">
    ${items.map((item) => `<div class="check-row"><span class="check-box"></span><span>${rich(stripTag(item, 'MORIChecklist').replace(/^☐\s*/, ''))}</span></div>`).join('\n    ')}
  </div>`;
}

function renderExamples(items) {
  return `<div class="examples">
    ${items.map((item) => `<div class="example-row">${rich(stripTag(item, 'MORISpanishExample'))}</div>`).join('\n    ')}
  </div>`;
}

function renderDialogue(items) {
  return `<div class="dialogue">
    <div class="card-label">מיני דיאלוג</div>
    ${items.map((item) => `<div class="dialogue-row">${rich(stripTag(item, 'MORIDialogue'))}</div>`).join('\n    ')}
  </div>`;
}

function renderExercises(items) {
  return `<div class="exercise">
    <div class="card-label">תרגול</div>
    ${items.map((item) => `<div class="exercise-row">${rich(stripTag(item, 'MORIExerciseItem'))}</div>`).join('\n    ')}
  </div>`;
}

function renderTable(rows) {
  const parsed = rows.map((row) => row.split('||').map((cell) => cell.trim()));
  const [header, ...body] = parsed;
  return `<div class="table-wrap"><table dir="rtl">
    <thead><tr>${header.map((cell) => `<th>${rich(cell)}</th>`).join('')}</tr></thead>
    <tbody>${body.map((row) => `<tr>${row.map((cell) => `<td>${rich(cell)}</td>`).join('')}</tr>`).join('\n    ')}</tbody>
  </table></div>`;
}

function renderKeyword(value) {
  return `<div class="keyword">${rich(value)}</div>`;
}

function renderPlain(chunk) {
  if (!chunk.length) return '';
  const labelOnly = chunk.length === 1 && /[:：]$/.test(chunk[0]);
  if (labelOnly) return `<p class="lead-label">${rich(chunk[0])}</p>`;

  const firstIsLabel = /[:：]$/.test(chunk[0]);
  if (firstIsLabel) {
    return `<div class="note-card"><div class="card-label">${rich(chunk[0].replace(/[:：]$/, ''))}</div><p>${rich(chunk.slice(1).join(' '))}</p></div>`;
  }
  return `<p>${rich(chunk.join(' '))}</p>`;
}

function renderBody(items) {
  const html = [];
  let i = 0;
  while (i < items.length) {
    const line = items[i];

    if (line.startsWith('[Heading2]')) {
      const heading = stripTag(line, 'Heading2');
      const chapter = titleParts(heading);
      let subtitle = '';
      if (items[i + 1]?.startsWith('[MORIChapterSubtitle]')) {
        subtitle = stripTag(items[i + 1], 'MORIChapterSubtitle');
        i += 1;
      }
      if (chapter) {
        html.push(`<section class="chapter-head"><div class="chapter-meta"><span class="chapter-pill">פרק ${chapter.chapter}</span>${subtitle ? `<span class="chapter-subtitle">${rich(subtitle)}</span>` : ''}</div><h2>${rich(chapter.title)}</h2></section>`);
      } else {
        html.push(`<section class="review-head"><span>עצירה וחזרה</span><h2>${rich(heading)}</h2></section>`);
      }
      i += 1;
      continue;
    }

    if (line.startsWith('[Heading3]')) {
      html.push(`<h3>${rich(stripTag(line, 'Heading3'))}</h3>`);
      i += 1;
      continue;
    }

    if (line.startsWith('[MORISpanishExample]')) {
      const { grouped, next } = groupWhile(items, i, '[MORISpanishExample]');
      html.push(renderExamples(grouped));
      i = next;
      continue;
    }

    if (line.startsWith('[MORIDialogue]')) {
      const { grouped, next } = groupWhile(items, i, '[MORIDialogue]');
      html.push(renderDialogue(grouped));
      i = next;
      continue;
    }

    if (line.startsWith('[MORIExerciseItem]')) {
      const { grouped, next } = groupWhile(items, i, '[MORIExerciseItem]');
      html.push(renderExercises(grouped));
      i = next;
      continue;
    }

    if (line.startsWith('[MORIChecklist]')) {
      const { grouped, next } = groupWhile(items, i, '[MORIChecklist]');
      html.push(renderChecklist(grouped));
      i = next;
      continue;
    }

    if (line.startsWith('[MORIKeyword]')) {
      html.push(renderKeyword(stripTag(line, 'MORIKeyword')));
      i += 1;
      continue;
    }

    if (line === '[TABLE]') {
      const rows = [];
      i += 1;
      while (i < items.length && items[i] !== '[/TABLE]') {
        rows.push(items[i]);
        i += 1;
      }
      html.push(renderTable(rows));
      i += 1;
      continue;
    }

    if (line.startsWith('[MORISmallNote]')) {
      html.push(`<div class="small-note">${rich(stripTag(line, 'MORISmallNote'))}</div>`);
      i += 1;
      continue;
    }

    if (line.startsWith('[MORISubsectionHeading]')) {
      html.push(`<div class="subsection-label">${rich(stripTag(line, 'MORISubsectionHeading'))}</div>`);
      i += 1;
      continue;
    }

    if (line.startsWith('[MORISectionHeading]')) {
      html.push(`<h3 class="section-heading">${rich(stripTag(line, 'MORISectionHeading'))}</h3>`);
      i += 1;
      continue;
    }

    if (line.startsWith('[MORIChapterSubtitle]')) {
      i += 1;
      continue;
    }

    if (line.startsWith('[')) {
      html.push(`<div class="small-note">${rich(line.replace(/^\[[^\]]+\]\s*/, ''))}</div>`);
      i += 1;
      continue;
    }

    const chunk = [];
    while (i < items.length && !/^\[(Heading2|Heading3|MORI|TABLE|\/TABLE)/.test(items[i])) {
      chunk.push(items[i]);
      i += 1;
      if (/[:：]$/.test(chunk[chunk.length - 1])) break;
    }
    html.push(renderPlain(chunk));
  }
  return html.join('\n\n');
}

function parseUnits() {
  const starts = [];
  lines.forEach((line, index) => {
    if (line.startsWith('[MORIUnitKicker]')) starts.push(index);
  });

  return starts.map((start, position) => {
    const end = starts[position + 1] ?? lines.length;
    const unitLines = lines.slice(start, end);
    const number = unitNumber(stripTag(unitLines[0], 'MORIUnitKicker'));
    const title = stripTag(unitLines[1], 'Heading1');
    const subtitle = stripTag(unitLines[2], 'MORIUnitSubtitle');
    const goal = unitLines[3].replace(/^מטרת היחידה:\s*/, '');
    const firstChapter = unitLines.findIndex((entry) => entry.startsWith('[Heading2]'));
    const openerLines = unitLines.slice(4, firstChapter);
    const outcomes = openerLines.filter((entry) => entry.startsWith('[MORIChecklist]'));
    const body = unitLines.slice(firstChapter);
    return { number, title, subtitle, goal, outcomes, body };
  });
}

function renderOpener(unit) {
  const number = String(unit.number).padStart(2, '0');
  return `<section class="unit-opener">
    <div class="orb"></div><div class="arch"></div>
    <div class="unit-top"><span>יחידה ${number}</span><b>${number}</b></div>
    <div class="unit-title"><h1>${rich(unit.title)}</h1><div>${rich(unit.subtitle)}</div></div>
    <div class="unit-goal"><span>מטרת היחידה</span><p>${rich(unit.goal)}</p></div>
    <div class="unit-outcomes"><strong>בסיום היחידה אוכל:</strong>${renderChecklist(unit.outcomes, true)}</div>
    <div class="opener-note">להבין · להגיד · להשתמש</div>
  </section>`;
}

function renderDocument(unit) {
  const number = String(unit.number).padStart(2, '0');
  const prev = unit.number === 1 ? '00 Cover + Front.dc.html' : `Unit ${String(unit.number - 1).padStart(2, '0')}.dc.html`;
  const next = unit.number === 10 ? '00 Cover + Front.dc.html' : `Unit ${String(unit.number + 1).padStart(2, '0')}.dc.html`;
  const nextText = unit.number === 10 ? 'לחזור לתוכן העניינים ←' : `להמשיך ליחידה ${unit.number + 1} ←`;
  return `<!DOCTYPE html>
<html lang="he" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>יחידה ${number} · ${esc(plain(unit.title))}</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Frank+Ruhl+Libre:wght@400;500;700;900&family=Assistant:wght@400;600;700&display=swap" rel="stylesheet">
<style>${styles}</style>
</helmet>
<x-import component-from-global-scope="doc-page" from="./doc-page.js" size="a4" orientation="portrait" margin="14mm" hint-size="100%,1123px">
<div slot="footer" class="footer"><span>ספרדית בלי כאב ראש · מושיק גואטה</span><span>יחידה ${number} · ${esc(plain(unit.title))}</span></div>
<main dir="rtl" lang="he">
${renderOpener(unit)}
${renderBody(unit.body)}
<nav class="unit-nav"><a href="${prev}">→ ליחידה הקודמת</a><a class="next" href="${next}">${nextText}</a></nav>
</main>
</x-import>
</x-dc>
</body>
</html>\n`;
}

const styles = `
:root{--navy:${palette.navy};--rust:${palette.rust};--gold:${palette.gold};--cream:${palette.cream};--ink:${palette.ink};--muted:${palette.muted};--green:${palette.green}}
*{box-sizing:border-box}
body{margin:0;background:#EFEAE0;color:var(--ink)}
a{color:var(--navy);text-decoration:none}a:hover{color:var(--rust)}
doc-page:not(:defined){visibility:hidden}
main{font:400 15px/1.75 Assistant,sans-serif;text-align:right}
.footer{display:flex;justify-content:space-between;font:600 10.5px Assistant,sans-serif;color:#A99F8D;padding-top:6px;border-top:1px solid #EDE6D8}
.unit-opener{height:246mm;background:var(--navy);border-radius:12px;position:relative;overflow:hidden;color:#F6EFE2;padding:18mm 16mm;display:flex;flex-direction:column;break-after:page;break-inside:avoid}
.orb{position:absolute;left:-30mm;bottom:-30mm;width:90mm;height:90mm;border-radius:50%;background:var(--gold);opacity:.9}
.arch{position:absolute;left:40mm;bottom:24mm;width:34mm;height:17mm;border-radius:34mm 34mm 0 0;background:var(--rust)}
.unit-top{display:flex;justify-content:space-between;align-items:center;position:relative}.unit-top span{font:700 13px Assistant,sans-serif;letter-spacing:.14em;color:var(--gold)}.unit-top b{font:900 60px 'Frank Ruhl Libre',serif;color:rgba(246,239,226,.16);line-height:1}
.unit-title{margin-top:22mm;position:relative}.unit-title h1{font:900 46px/1.15 'Frank Ruhl Libre',serif;margin:0}.unit-title div{font:400 19px Assistant,sans-serif;color:#C8D2DE;margin-top:8px}
.unit-goal{border-top:1px solid rgba(246,239,226,.25);margin-top:14mm;padding-top:14px;position:relative;max-width:130mm}.unit-goal span{font:700 12.5px Assistant,sans-serif;color:var(--gold);letter-spacing:.08em}.unit-goal p{font:400 16px/1.7 Assistant,sans-serif;margin:3px 0}
.unit-outcomes{margin-top:12mm;position:relative;max-width:125mm}.unit-outcomes>strong{font:700 15px Assistant,sans-serif}.unit-outcomes .check-card{border:0;padding:0;margin:8px 0;background:transparent}.unit-outcomes .check-box{border-color:var(--gold)}
.opener-note{margin-top:auto;text-align:left;position:relative;font:700 12px Assistant,sans-serif;letter-spacing:.22em;color:#8FA2B8}
.chapter-head{border-bottom:3px solid var(--navy);padding-bottom:14px;margin:0 0 20px;break-before:page}.chapter-meta{display:flex;justify-content:space-between;align-items:center}.chapter-pill{background:var(--rust);color:var(--cream);font:700 13px Assistant,sans-serif;padding:4px 14px;border-radius:999px}.chapter-subtitle{font:500 15px 'Frank Ruhl Libre',serif;color:var(--muted)}.chapter-head h2,.review-head h2{font:900 30px/1.2 'Frank Ruhl Libre',serif;color:var(--navy);margin:10px 0 0}
.review-head{background:#F7EBD4;border-right:5px solid var(--gold);border-radius:10px;padding:14px 18px;margin:28px 0 18px;break-before:page}.review-head span{font:700 12px Assistant,sans-serif;color:#8A6414;letter-spacing:.08em}
h3{font:700 20px/1.3 'Frank Ruhl Libre',serif;color:var(--navy);margin:24px 0 10px;break-after:avoid}p{margin:0 0 10px}
.es{font-family:'Frank Ruhl Libre',serif;font-weight:600;color:var(--rust);unicode-bidi:isolate}
.examples{margin:0 0 14px;break-inside:avoid}.example-row{padding:7px 2px;border-bottom:1px solid #F1EBDF;min-height:35px}.example-row .es{font-size:16px}
.dialogue{background:#EEF2F6;border-right:4px solid var(--navy);border-radius:10px;padding:14px 18px;margin:12px 0;break-inside:avoid}.dialogue-row{padding:5px 0;border-bottom:1px solid #DCE4EC}.dialogue-row:last-child{border:0}
.exercise{background:#EAF1EC;border-radius:10px;padding:14px 18px;margin:12px 0;break-inside:avoid}.exercise-row{padding:6px 0;border-bottom:1px solid #D5E3DA}.exercise-row:last-child{border:0}.exercise .es{color:var(--navy)}
.card-label,.subsection-label{font:700 12.5px Assistant,sans-serif;color:var(--green);margin-bottom:6px;letter-spacing:.04em}.dialogue .card-label{color:var(--navy)}
.check-card{border:1.5px solid var(--navy);border-radius:12px;padding:14px 18px;margin:12px 0;display:grid;gap:7px;break-inside:avoid}.check-row{display:flex;gap:10px;align-items:baseline}.check-box{flex:none;width:12px;height:12px;border:1.5px solid var(--navy);border-radius:3px;transform:translateY(1px)}
.table-wrap{margin:12px 0 16px;break-inside:avoid}table{width:100%;border-collapse:collapse;font-size:14px}th{background:var(--navy);color:var(--cream);font:600 13px Assistant,sans-serif;padding:8px 12px;text-align:right}td{padding:7px 12px;border-bottom:1px solid #EDE6D8;vertical-align:top}td .es{font-size:15px}
.keyword{background:var(--navy);color:var(--cream);border-radius:10px;padding:13px 18px;margin:12px 0;text-align:center;font-size:21px;break-inside:avoid}.keyword .es{color:var(--gold);font-size:24px}
.note-card{border:1px solid #E5C3B2;border-radius:10px;padding:12px 16px;margin:12px 0;break-inside:avoid}.note-card .card-label{color:var(--rust)}.note-card p{margin:0}
.lead-label{font-weight:700;color:var(--navy);margin-top:8px}.small-note{font:700 12px Assistant,sans-serif;letter-spacing:.16em;color:var(--muted);margin:10px 0}.subsection-label{color:var(--navy);font-size:14px}
.section-heading{background:var(--navy);color:var(--cream);border-radius:8px;padding:10px 14px;margin-top:22px}
.unit-nav{display:flex;justify-content:space-between;align-items:center;border-top:1px solid #E1D9CB;margin-top:28px;padding-top:16px;break-before:avoid}.unit-nav a{font:700 14px Assistant,sans-serif;color:var(--muted)}.unit-nav .next{display:inline-block;background:var(--navy);color:#F6EFE2;border-radius:999px;padding:9px 24px}
@media(max-width:720px){.unit-opener{height:auto;min-height:88vh;padding:42px 28px}.unit-title{margin-top:56px}.unit-title h1{font-size:38px}.unit-goal{margin-top:48px}.unit-outcomes{margin-top:34px}.table-wrap{overflow-x:auto}.chapter-head{break-before:auto}.review-head{break-before:auto}}
@media print{body{background:#fff}.unit-nav{display:none}}
`;

const selected = parseUnits().filter((unit) => unit.number >= 3 && unit.number <= 10);
for (const unit of selected) {
  const filename = `Unit ${String(unit.number).padStart(2, '0')}.dc.html`;
  fs.writeFileSync(path.join(root, filename), renderDocument(unit), 'utf8');
}

console.log(`Built ${selected.length} units: ${selected.map((unit) => unit.number).join(', ')}`);
